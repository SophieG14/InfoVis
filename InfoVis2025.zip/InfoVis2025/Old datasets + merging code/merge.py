import pandas as pd
import pycountry
import pycountry_convert as pc

beer_df = pd.read_csv("beer-consumption-per-person.csv")
wine_df = pd.read_csv("wine-consumption-per-capita.csv")
spirits_df = pd.read_csv("spirits-consumption-per-person.csv")
total_alcohol_df = pd.read_csv("total-alcohol-consumption-per-capita-litres-of-pure-alcohol.csv")
mental_health_df = pd.read_csv("Mental health Depression disorder Data.csv", low_memory=False)

for df in [beer_df, wine_df, spirits_df, total_alcohol_df, mental_health_df]:
    df.columns = df.columns.str.strip()

beer_df = beer_df.rename(columns={beer_df.columns[-1]: 'beer_consumption'})
wine_df = wine_df.rename(columns={wine_df.columns[-1]: 'wine_consumption'})
spirits_df = spirits_df.rename(columns={spirits_df.columns[-1]: 'spirits_consumption'})
total_alcohol_df = total_alcohol_df.rename(columns={total_alcohol_df.columns[-1]: 'total_alcohol_consumption'})

beer_df = beer_df[['Entity', 'Year', 'beer_consumption']]
wine_df = wine_df[['Entity', 'Year', 'wine_consumption']]
spirits_df = spirits_df[['Entity', 'Year', 'spirits_consumption']]
total_alcohol_df = total_alcohol_df[['Entity', 'Year', 'total_alcohol_consumption']]

mental_health_df = mental_health_df.drop(columns=['index', 'Code'])
mental_health_df['Year'] = pd.to_numeric(mental_health_df['Year'], errors='coerce')
mental_health_df = mental_health_df[(mental_health_df['Year'] >= 2000) & (mental_health_df['Year'] <= 2017)]
mental_health_df = mental_health_df.rename(columns=lambda x: x.replace(' (%)', '').strip())

for df in [beer_df, wine_df, spirits_df, total_alcohol_df]:
    df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
    df.dropna(subset=['Year'], inplace=True)
    df['Year'] = df['Year'].astype(int)
    df = df[(df['Year'] >= 2000) & (df['Year'] <= 2017)]

merged_df = beer_df.merge(wine_df, on=['Entity', 'Year'], how='inner') \
                   .merge(spirits_df, on=['Entity', 'Year'], how='inner') \
                   .merge(total_alcohol_df, on=['Entity', 'Year'], how='inner') \
                   .merge(mental_health_df, on=['Entity', 'Year'], how='inner')

countries_complete = merged_df.groupby('Entity').filter(lambda x: len(x['Year'].unique()) == 18)['Entity'].unique()
final_df = merged_df[merged_df['Entity'].isin(countries_complete)].sort_values(['Entity', 'Year'])

def get_continent(country_name):
    try:
        overrides = {
            'United States': 'United States of America',
            'Czech Republic': 'Czechia',
            'Russia': 'Russian Federation',
            'South Korea': 'Korea, Republic of',
            'North Korea': 'Korea, Democratic People\'s Republic of',
            'Iran': 'Iran, Islamic Republic of',
            'Vietnam': 'Viet Nam',
            'Syria': 'Syrian Arab Republic',
            'Tanzania': 'Tanzania, United Republic of',
            'Bolivia': 'Bolivia, Plurinational State of',
            'Venezuela': 'Venezuela, Bolivarian Republic of',
            'Laos': 'Lao People\'s Democratic Republic',
            'Moldova': 'Moldova, Republic of',
            'Brunei': 'Brunei Darussalam',
            'Libya': 'Libyan Arab Jamahiriya',
            'Micronesia (country)': 'Micronesia, Federated States of',
            'Cape Verde': 'Cabo Verde'
        }
        name = overrides.get(country_name, country_name)
        country = pycountry.countries.lookup(name)
        alpha2 = country.alpha_2
        continent_code = pc.country_alpha2_to_continent_code(alpha2)
        return pc.convert_continent_code_to_continent_name(continent_code)
    except:
        return None

final_df['Continent'] = final_df['Entity'].apply(get_continent)

democracy_df = pd.read_excel("continents demo.xlsx")
democracy_df.columns = democracy_df.columns.str.strip()
democracy_df = democracy_df.rename(columns={
    'Continent': 'Source_Region',
    'Average Score': 'democracy_index'
})
democracy_df['Year'] = pd.to_numeric(democracy_df['Year'], errors='coerce')

region_to_continent = {
    'Europe': 'Europe',
    'Africa': 'Africa',
    'Western Asia': 'Asia',
    'Americas': 'North America', 
    'Asia and the Pacific': 'Oceania'
}
democracy_df['Continent'] = democracy_df['Source_Region'].map(region_to_continent)

americas_rows = democracy_df[democracy_df['Source_Region'] == 'Americas'].copy()
americas_rows['Continent'] = 'South America'

democracy_expanded_df = pd.concat([democracy_df, americas_rows], ignore_index=True)

expanded_scores = democracy_expanded_df[['Continent', 'Year', 'democracy_index']].dropna().drop_duplicates()
final_df = final_df.merge(expanded_scores, on=['Continent', 'Year'], how='left')

final_df.to_csv("Dataset.csv", index=False)

